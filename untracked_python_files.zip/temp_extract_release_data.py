#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 12:14:20 2024

@author: marik
"""

from extract_release_data import find_release_data_one_measurement


a = find_release_data_one_measurement()