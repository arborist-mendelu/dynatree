#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 22:31:56 2024

@author: marik
"""

import pandas as pd
import numpy as np

df = pd.read_csv("results/fft.csv")
df2 = pd.read_csv("results/fft_tail_2.csv")

#%%


# Sloučíme DataFrame
merged_df = pd.merge(df, df2, on=['date', 'tree', 'measurement', 'probe'])

merged_df["delta"] = np.abs(merged_df["freq_x"]-merged_df["freq_y"])
# Výsledek je v merged_df
#%%

mdf = merged_df.sort_values(by="delta").dropna()

mdf = mdf[mdf['probe'].apply(lambda x:x[2:4])=="Pt"]
