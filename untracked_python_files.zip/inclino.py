#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 16:22:44 2023

@author: marik
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


data = pd.read_csv("../01_Mereni_Babice_05042022_optika_zpracovani/csv_extended/BK10_M03.csv",header=[0,1], index_col=0, dtype = np.float64)

sloupce = [i for i in data.columns if "Incli" in i[0]]
data[sloupce].plot(style='.')
