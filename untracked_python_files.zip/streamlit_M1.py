#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 23 12:37:18 2024

@author: marik
"""

import pandas as pd
import glob
import os
# from scipy.stats import linregres
import matplotlib.pyplot as plt
import numpy as np
import streamlit as st


plt.rcParams["figure.figsize"] = (10,4)

fs = 100 # resampled signal
files = glob.glob("../01_Mereni_Babice_*_optika_zpracovani/csv/*")
data = [{'year':i[24:28], 'month': i[22:24], 'day': i[20:22], 'measurement': i[-6:-4], 'tree':i[-10:-8],
         'date': f"{i[24:28]}-{i[22:24]}-{i[20:22]}"} for i in files]

# df_osc_times = pd.read_csv("csv/oscillation_times_remarks.csv")

#%%


"""
## Day, tree, measurement
"""
columns = st.columns(2)

dates = np.unique(np.array([f"{i['date']}"for i in data]))
dates.sort()
with columns[0]:
    date = st.radio("Day",dates, horizontal=True)

trees = np.unique(np.array([i['tree'] for i in data if i['date']==date]))
trees.sort()
with columns[1]:
    tree = st.radio("Tree",trees, horizontal=True)


measurement = "1"


#%%

#%%

df_pt_notes = pd.read_csv("./csv/PT_notes_with_pt.csv", sep=",")


year,month,day=date.split("-")
df = pd.read_csv(f"../01_Mereni_Babice_{day}{month}{year}_optika_zpracovani/pulling_tests/BK_{tree}_M{measurement}.TXT",
                  skiprows=55, 
                  decimal=",",
                  sep='\t+',    
                  skipinitialspace=True,
                  na_values="-", 
                  engine='python'
)

df["Time"] = df["Time"] - df["Time"][0]
df.index = df["Time"]



def split_df_static_pulling(df_ori):
    """
    Analyzes data in static tests, with three pulls. Inputs the dataframe, 
    outputs the list of dictionaries with minimal force, maximal force 
    """
    df = df_ori.copy()
    # Divide domain into interval where force is large and small
    maximum = df["Force(100)"].max()
    df["Force_step"] = df["Force(100)"].max()
    df.loc[df["Force(100)"]<0.5*maximum, "Force_step"] = 0
    df.loc[df["Force(100)"].isna(), "Force_step"] = np.nan
    
    diffs = df["Force_step"].dropna().diff()
    steps = diffs[diffs!=0.0].dropna()
    
    # print(f"Steps index:{steps.index}")
    
    interval_start = np.array([0.0]+list(steps.index))
    interval_end = np.roll(interval_start,-1)
    
    i = 0
    time = []
    for start,end in zip (interval_start, interval_end):
        if start > end:
            continue
        i = i+1
        if i % 2 == 1:
            # odd interval, save the bounds and skip to the next interval
            prev_start = start
            prev_end = end
            continue
        df_subset = df.loc[start:end,"Force(100)"]
        maximum_idx = np.argmax(df_subset)
        t = {'maximum': df_subset.index[maximum_idx]}
        maximum_force = np.max(df_subset)
        upper_limit_force_idx = np.argmax(df_subset>0.8*maximum_force)
        upper_limit_force_time = df_subset.index[upper_limit_force_idx]
        t['upper_limit_force'] = upper_limit_force_time
    
        df_subset = df.loc[prev_start:prev_end,"Force(100)"]
        idxmin = df_subset.idxmin()
        t['minimum'] = idxmin
    
        df_subset = df_subset[idxmin:]
        df_subset = df_subset[::-1]
        
        lower_limit_force_idx = np.argmax(df_subset<0.2*maximum_force)
        lower_limit_force_time = df_subset.index[lower_limit_force_idx]
        t['lower_limit_force'] = lower_limit_force_time
        time = time + [t]
    return time


# Visual cchecking

time = split_df_static_pulling(df)
fig, ax = plt.subplots()
df[["Force(100)"]].plot(ax=ax)
ax.grid()
for _ in time:
    s = _["minimum"]
    e = _["maximum"]
    df.loc[s:e,"Force(100)"].plot(color="C0", lw=4, ax=ax)
    s = _["lower_limit_force"]
    e = _["upper_limit_force"]
    df.loc[s:e,"Force(100)"].plot(lw=4, ax=ax)
st.pyplot(fig)

#%% 
   

def tand(angle):
    """
    Evaluates tangens of the angle. The angli is in degrees.
    """
    return np.tan(np.deg2rad(angle))
def arctand(value):
    """
    Evaluates arctan. Return the angle in degrees.
    """
    return np.rad2deg(np.arctan(value))

def process_inclinometers(df, height_of_anchorage=None, rope_angle=None, 
                          height_of_pt=None):
    """
    The input is dataframe as produced by read_data(f"{adresar}/{date}/csv_extended/BK{tree}_M0{measurement}.csv")
    i.e. inclinometers data resamples to the times from optics and synchronized.
    
    * Converts Inclino(80) and Inclino(81) to blue and yellow respectively.
    * Evaluates the total angle of inclination
    * Evaluates horizontal and vertical forces
    * 
    """
    # convert multiindex to single index
    sloupce = df.columns
    # sloupce = [f"{i[0]}/{i[1]}" for i in sloupce]
    sloupce = [i.replace("Inclino(80)","blue").replace("Inclino(81)","yellow") for i in sloupce]    
    df.columns = sloupce    
        #process columns
    df.loc[:,["blue"]] = arctand(np.sqrt((tand(df["blueX"]))**2 + (tand(df["blueY"]))**2 ))
    df.loc[:,["yellow"]] = arctand(np.sqrt((tand(df["yellowX"]))**2 + (tand(df["yellowY"]))**2 ))    
    for inclino in ["blue","yellow"]:
         # najde maximum bez ohledu na znamenko
         maxima = df[[f"{inclino}X",f"{inclino}Y"]].abs().max()
         # vytvori sloupce blue_Maj, blue_Min, yellow_Maj,  yellow_Min....hlavni a vedlejsi osa
         if maxima[f"{inclino}X"]>maxima[f"{inclino}Y"]:
             df.loc[:,[f"{inclino}_Maj"]] = df[f"{inclino}X"]
             df.loc[:,[f"{inclino}_Min"]] = df[f"{inclino}Y"]
         else:
             df.loc[:,[f"{inclino}_Maj"]] = df[f"{inclino}Y"]
             df.loc[:,[f"{inclino}_Min"]] = df[f"{inclino}X"]
         # Najde pozici, kde je extremalni hodnota - nejkladnejsi nebo nejzapornejsi
         idx = df[f"{inclino}_Maj"].abs().idxmax()
         # promenna bude jednicka pokus je extremalni hodnota kladna a minus
         # jednicka, pokud je extremalni hodnota zaporna
         znamenko = np.sign(df[f"{inclino}_Maj"][idx])
         # V zavisosti na znamenku se neudela nic nebo zmeni znamenko ve sloupcich
         # blueM, blueV, yellowM, yellowV
         for axis in ["_Maj", "_Min"]:
             df.loc[:,[f"{inclino}{axis}"]] = znamenko * df[f"{inclino}{axis}"]    
         # convert index to multiindex
    # evaluate the horizontal and vertical component
    if rope_angle is None:
        # If rope angle is not given, use the data from the table
        rope_angle = df['RopeAngle(100)']
    # evaluate horizontal and vertical force components and moment
    df.loc[:,['F_horizontal']] = df['Force(100)'] * np.cos(np.deg2rad(rope_angle))
    df.loc[:,['F_vertical']] = df['Force(100)'] * np.sin(np.deg2rad(rope_angle))
    df.loc[:,['M']] = df['F_horizontal'] * height_of_anchorage
    df.loc[:,['M_Pt']] = df['F_horizontal'] * ( height_of_anchorage - height_of_pt )
    sloupce = [i.split("/") for i in df.columns]
    sloupce = [i if len(i)>1 else [i[0],'nan'] for i in sloupce ]
    # df.columns = pd.MultiIndex.from_tuples(sloupce)
    return df

# Rope angle
rope_angle = df_pt_notes[df_pt_notes["tree"]==int(tree)][["angle_of_anchorage"]].iat[0,0]
# Plot the rope angle to check, if it contains data which can be used
# ax = df_extra['RopeAngle(100)'].plot()
# ax.set(title=f"{date} Tree {tree} M0{measurement}")
# Find the height of anchorage from the csv file
# df_pt = pd.read_csv("PT_notes/PT_notes_with_pt.csv", sep=",", index_col=0)
height_of_anchorage = df_pt_notes.at[int(tree),'height_of_anchorage']
height_of_pt = df_pt_notes.at[int(tree),'height_of_pt']

for _ in time:
    s = _["lower_limit_force"]
    e = _["upper_limit_force"]
    df_subset = df.loc[s:e,:]
    df_subset = process_inclinometers(df_subset, height_of_anchorage=height_of_anchorage, 
                                      rope_angle=rope_angle, height_of_pt=height_of_pt)
    fig,ax = plt.subplots()
    for color in ["blue","yellow"]:
        df_subset.loc[:,[color,"M"]].plot(x=color, ax=ax)
    st.pyplot(fig)

