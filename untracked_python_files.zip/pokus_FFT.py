#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  7 22:23:53 2023

@author: marik
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import rfft
from scipy.fft import rfftfreq

# Sample spacing
T = 10 
sampling = 100
N = T*sampling

# Create a signal
x = np.linspace(0.0, T, N)
t0 = np.pi/6   # non-zero phase of the second sine
y = np.sin(5.0 * 2.0*np.pi*x) + 0.5*np.sin(25.0 * 2.0*np.pi*x + t0)
yf = rfft(y)

amplitude = 2/N*np.abs(yf)
threshold = 0.1
phase = np.angle(yf, deg=True)
phase[amplitude<threshold] = 0

# Where is a 200 Hz frequency in the results?
freq = rfftfreq(x.size, d=1/sampling)
# index, = np.where(np.isclose(freq, 200, atol=1/(T*N)))

# Get magnitude and phase
# magnitude = np.abs(yf[index[0]])
# phase = np.angle(yf[index[0]])
# print("Magnitude:", magnitude, ", phase:", phase)

# Plot a spectrum 
fig, ax = plt.subplots()
ax.plot(freq, amplitude,".", label='amplitude spectrum')   # in a conventional form
ax = plt.twinx(ax)

ax.plot(freq, phase, ".", label='phase spectrum', color="C1")
fig.legend()
plt.grid()
plt.show()