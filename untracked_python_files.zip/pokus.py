#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 14:02:22 2023

@author: marik
"""

import streamlit as st
import numpy as np
import matplotlib.pyplot as plt

def exp_function(x, k):
    return np.exp(k * x)

def plot_function(k):
    x = np.linspace(0, 5, 100)
    y = exp_function(x, k)

    plt.plot(x, y)
    plt.title(f'Graf funkce exp({k}*x)')
    plt.xlabel('x')
    plt.ylabel('exp(k*x)')
    plt.grid(True)

    return plt

def main():
    st.title('Streamlit Aplikace s Grafem')

    k_value = st.slider('Vyberte hodnotu k:', 0.0, 10.0, 5.0, 0.1)

    st.pyplot(plot_function(k_value))

if __name__ == '__main__':
    main()


