#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  3 18:51:20 2024

@author: marik
"""

import pandas as pd

import scipy.io
mat = scipy.io.loadmat('2021-03-22-BK04-M02.mat')


#%%
df = pd.read_csv("../acc/data.csv")


#%%

df = df - df.iloc[0,:]
time = df['Data1_time_A01_x']

#%%

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

y = df['Data1_A01_z']

smoothed_y = savgol_filter(y, window_length=1000, polyorder=2)  # Změna hodnot window_length a polyorder může ovlivnit úroveň vyhlazení

#%%
fig, ax = plt.subplots()
ax.plot(time,smoothed_y)
ax.set(ylim=(-.1,.1))

#%%

