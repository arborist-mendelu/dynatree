#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 19:31:14 2023

@author: marik
"""

import pandas as pd

from lib_dynatree import read_data


df_remarks = pd.read_csv("csv/oscillation_times_remarks.csv")
df = read_data(f"../01_Mereni_Babice_16082022_optika_zpracovani/csv/BK11_M03.csv")

#%%

idx = ~pd.isna(df.index)
df = df[idx]

#%%

df = df.loc[105:130,("Pt3","Y0")]

#%%

df = df - df.mean()

#%%
from findpeaks import findpeaks
fp = findpeaks(method='peakdetect', lookahead=200, interpolate=None)
X = df.values
results = fp.fit(X)
fp.plot()

#%%

fp.plot_persistence()