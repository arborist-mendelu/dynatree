#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 08:22:35 2024

@author: marik
"""

import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
adresar = '../'
# sys.path.append('./ERC/ERC/01_Mereni_Babice_optika_skripty/')
from extract_release_data import find_release_data_one_measurement
from lib_dynatree import read_data, read_data_selected

def tand(angle):
    """
    Evaluates tangens of the angle. The angli is in degrees.
    """
    return np.tan(np.deg2rad(angle))
def arctand(value):
    """
    Evaluates arctan. Return the angle in degrees.
    """
    return np.rad2deg(np.arctan(value))

def process_inclinometers(df, height_of_anchorage=None, rope_angle=None):
    """
    The input is dataframe as produced by read_data(f"{adresar}/{date}/csv_extended/BK{tree}_M0{measurement}.csv")
    i.e. inclinometers data resamples to the times from optics and synchronized.
    
    * Converts Inclino(80) and Inclino(81) to blue and yellow respectively.
    * Evaluates the total angle
    * 
    """
    # convert multiindex to single index
    sloupce = df.columns
    sloupce = [f"{i[0]}/{i[1]}" for i in sloupce]
    sloupce = [i.replace("/nan","").replace("Time/","Time").replace("Inclino(80)","blue").replace("Inclino(81)","yellow") for i in sloupce]    
    df.columns = sloupce    
        #process columns
    df["blue"] = arctand(np.sqrt((tand(df["blueX"]))**2 + (tand(df["blueY"]))**2 ))
    df["yellow"] = arctand(np.sqrt((tand(df["yellowX"]))**2 + (tand(df["yellowY"]))**2 ))    
    for inclino in ["blue","yellow"]:
         # najde maximum bez ohledu na znamenko
         maxima = df[[f"{inclino}X",f"{inclino}Y"]].abs().max()
         # vytvori sloupce blue_Maj, blue_Min, yellow_Maj,  yellow_Min....hlavni a vedlejsi osa
         if maxima[f"{inclino}X"]>maxima[f"{inclino}Y"]:
             df[f"{inclino}_Maj"] = df[f"{inclino}X"]
             df[f"{inclino}_Min"] = df[f"{inclino}Y"]
         else:
             df[f"{inclino}_Maj"] = df[f"{inclino}Y"]
             df[f"{inclino}_Min"] = df[f"{inclino}X"]
         # Najde pozici, kde je extremalni hodnota - nejkladnejsi nebo nejzapornejsi
         idx = df[f"{inclino}_Maj"].abs().idxmax()
         # promenna bude jednicka pokus je extremalni hodnota kladna a minus
         # jednicka, pokud je extremalni hodnota zaporna
         znamenko = np.sign(df[f"{inclino}_Maj"][idx])
         # V zavisosti na znamenku se neudela nic nebo zmeni znamenko ve sloupcich
         # blueM, blueV, yellowM, yellowV
         for axis in ["_Maj", "_Min"]:
             df[f"{inclino}{axis}"] = znamenko * df[f"{inclino}{axis}"]    
         # convert index to multiindex
    # evaluate the horizontal and vertical component
    if rope_angle is None:
        # If rope angle is not given, use the data from the table
        rope_angle = df['RopeAngle(100)']
    # evaluate horizontal and vertical force components and moment
    df['F_horizontal'] = df['Force(100)'] * np.cos(np.deg2rad(rope_angle))
    df['F_vertical'] = df['Force(100)'] * np.sin(np.deg2rad(rope_angle))
    df['M'] = df['F_horizontal'] * height_of_anchorage
    sloupce = [i.split("/") for i in df.columns]
    sloupce = [i if len(i)>1 else [i[0],'nan'] for i in sloupce ]
    df.columns = pd.MultiIndex.from_tuples(sloupce)
    return df

#%%

date = "01_Mereni_Babice_22032021_optika_zpracovani"
tree = "04"
measurement = "2"

df_main = read_data_selected(f"{adresar}/{date}/csv/BK{tree}_M0{measurement}.csv")
df_extra = read_data(f"{adresar}/{date}/csv_extended/BK{tree}_M0{measurement}.csv")

ax = df_extra['RopeAngle(100)'].plot()
ax.set(title=f"{date} Tree {tree} M0{measurement}")

df_pt = pd.read_csv("csv/PT_notes.csv", sep="\t", index_col=0)
height_of_anchorage = df_pt.at[int(tree),'height_of_anchorage']

df_inclino = process_inclinometers(df_extra.copy(), height_of_anchorage=height_of_anchorage)

#%%
df_all = pd.concat(
        [df_main[["Time","Pt3","Pt4"]],
         df_inclino
         ], axis=1)

# pokud chces, muzes vymenit Pt3 za neco jineho
# df_all["Pt3"] = df_all["Pt3_fixed_by_11"]

#%%
max_force = np.nanmax(df_all['Force(100)'])
force_lower_limit = 0.1 * max_force
force_upper_limit = 0.9 * max_force
# find the first index where force is bigger than upper limit
force_upper_index = np.argmax(df_all['Force(100)']>force_upper_limit)
# find the first index where force is bigger than lower limit
force_lower_index = np.argmax(df_all['Force(100)']>force_lower_limit)

# The column which marks the data with initial phase when force increases
df_all['is_tension_phase'] = False
df_all.loc[df_all.index[force_lower_index]:df_all.index[force_upper_index],'is_tension_phase'] = True

#%%
for data in ['Force(100)','M']:
    fig, ax = plt.subplots()
    df_all[data].plot(ax=ax)
    df_all[df_all['is_tension_phase']==True][data].plot(ax=ax, title=data)
    plt.legend(['full experiment','pre-release'])
