#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 16:00:47 2023

@author: marik
"""

from csv_add_inclino import extend_one_csv
from plot_probes_inclino_force import plot_one_measurement

date="2022-08-16"
tree="24"
measurement="4"

extend_one_csv(date=date, tree=tree, measurement=measurement, write_csv=False)
# plot_one_measurement(date=date, tree=tree, measurement=measurement, save_figure=False)

