#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 21:42:38 2024

@author: marik
"""

import lib_dynatree as ld
import FFT_spectrum as fftd
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
column = ( 'Pt3',    'Y0')

data = fftd.load_data_for_FFT(file="../01_Mereni_Babice_05042022_optika_zpracovani/csv/BK04_M02.csv",start=110,end=130, #probes=["Time", "Elasto(90)"],
                              # probes=["Time",( 'Pt3',    'Y0')],
                              filter_cols=False)


#%%
output = fftd.do_fft_for_one_column(
    data, 
    column, 
    preprocessing=lambda x:fftd.extend_series_with_zeros(x,tail=2)
    ) 
fig = fftd.create_fft_image(**output)
plt.suptitle("data")
plt.tight_layout()

