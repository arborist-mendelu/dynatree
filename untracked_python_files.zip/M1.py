#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 09:17:19 2024

@author: marik
"""

import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

file = "../01_Mereni_Babice_05042022_optika_zpracovani/pulling_tests/BK_16_M1.TXT"

df_pulling_tests = pd.read_csv(
        file,
        skiprows=55, 
        decimal=",",
        sep='\t+',    
        skipinitialspace=True,
        na_values="-"
        )

ax = df_pulling_tests["Force(100)"].plot()
ax.set(ylim=(0,1))
ax.grid()