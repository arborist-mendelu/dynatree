#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 28 11:39:14 2023

@author: marik
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 27 02:14:14 2023

@author: marik
"""

from dash import Dash, html, dcc, callback, Output, Input, callback_context
from dash.exceptions import PreventUpdate
import plotly.express as px
import plotly.io as pio
import pandas as pd
import numpy as np
import dash_bootstrap_components as dbc
from lib_dynatree import do_fft
import os

pio.templates.default = "plotly_white"

# Initialize the app - incorporate a Dash Bootstrap theme
# external_stylesheets = [dbc.themes.BOOTSTRAP]
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])


popis = r"""
Studujeme rovnici 
$$
\frac {\mathrm dx}{\mathrm dt} = rx\left(1-\frac xK\right)-h.
$$
"""

app.layout =  dbc.Container(
    [ html.H1("Logistická rovnice s lovem", className="text-primary text-center fs-3"),
     dcc.Markdown(popis, mathjax=True),
     dbc.Row([html.Span("K", id='K-value'),
     dcc.Slider(0.1, 10, marks=None, id='K-slider', value=1)])
    ])

    
@callback(
    Output('K-value', 'children'),
    Input('K-slider', 'value')    
    )
def update(K):
    return dcc.Markdown(r"$K="+str(K)+r"$", mathjax=True)

if __name__ == '__main__':
    app.run(debug=True)