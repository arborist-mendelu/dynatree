#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 19:31:14 2023

@author: marik
"""

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
# import seaborn as sns
import matplotlib.pyplot as plt
# import scaleogram as scg 
# import pywt


from lib_dynatree import read_data

# choose default wavelet function for the entire notebook
# scg.set_default_wavelet('cmor1-1.5')

# Try these ones to see various compromises between scales and time resolution 
# scg.set_default_wavelet('cgau5')
#scg.set_default_wavelet('cgau1')
#scg.set_default_wavelet('shan0.5-2')
#scg.set_default_wavelet('mexh')

#%%

df_remarks = pd.read_csv("csv/oscillation_times_remarks.csv")
df = read_data(f"../01_Mereni_Babice_22032021_optika_zpracovani/csv/BK04_M03.csv")
freq1 = 0.239   # fft analyza
freq2 = 0.25    # odhad se scaleogramu

#%%

df[("Pt3","Y0")].plot()

#%%

df = df[df["Time"]>42]

#%%
time_ = df["Time"].values
data_ = df[("Pt3","Y0")].values

time = np.arange(time_[0], time_[-1], 0.01)
data = np.interp(time,time_, data_)
data = data - data.mean()
#%%

plt.subplots()
plt.plot(time,data)
sampling_period = 0.01
#%%
# Calculate continuous wavelet transform

# scales = np.arange(1, 1000)
wavelet = 'cmor1-1.5'
# f = pywt.scale2frequency(wavelet, scales)/sampling_period
# f

#%%

# plt.subplots()
# plt.specgram(data)

#%%
scales = np.arange(1, 1000)
coef, freqs = pywt.cwt(data, scales, wavelet,
                       sampling_period=sampling_period)

#%%
# Show w.r.t. time and frequency
plt.subplots()
plt.pcolormesh(time, freqs, np.log(np.abs(coef)),  cmap='jet', vmin=-3)
plt.colorbar()
# Set yscale, ylim and labels
# plt.yscale('log')
plt.ylim([0, 2.0])
plt.ylabel('Frequency (Hz)')
plt.xlabel('Time (sec)')

#%%

peak1 = np.argmin(freqs>freq1)
peak2 = np.argmin(freqs>freq2)
freqs[peak1-1], freqs[peak2-1]

plt.subplots()
plt.plot(time, np.abs(coef[peak1,:]), label=f'frekv {freq1}')
plt.plot(time, np.abs(coef[peak2,:]), label=f'frekv {freq2}')
plt.legend()

#%%

peak = peak1
plt.subplots()
abscoef = np.abs(coef[peak,:])
start = 700
end = -700
time_ = time[start:end]
abscoef_ = abscoef[start:end]

k,q = np.polyfit(time_, np.log(abscoef_), 1)

plt.plot(time, abscoef,label='Wavelet transformace')
plt.plot(time_,abscoef_,label='Wavelet transformace bez okrajů')
plt.plot(time_,np.exp(k*time_+q), label=f'Linearizace, $k={k:.4f}$')
plt.yscale('log')
plt.legend()
# plt.xlim(0,2)
# plt.ylim(0,None)

#%%

wavelet = pywt.ContinuousWavelet('morl')
print(wavelet)

wavelet.bandwidth_frequency = 9
wavelet.center_frequency = 10
psi,x = wavelet.wavefun(level=0, length=1000)
plt.plot(x,psi)
print(type(psi))
#%%

# Define parameters
omega_0 = 6
sampling_period = 0.1
t = np.arange(-10, 10, sampling_period)
# Compute Morlet wavelet
def morlet(t, omega_0):
    """
    Compute the Morlet wavelet.

    Parameters:
        t (array-like): Time array.
        omega_0 (float): Frequency parameter.

    Returns:
        psi (array-like): Morlet wavelet.
    """
    gaussian = np.exp(-0.5 * (t ** 2))
    complex_exponential = np.exp(1j * omega_0 * t)
    psi = gaussian * complex_exponential
    return psi
psi = morlet(t, omega_0)
# Plot Morlet wavelet
plt.figure(figsize=(8, 4))
plt.plot(t, np.real(psi), label='Real part')
plt.plot(t, np.imag(psi), label='Imaginary part')
plt.xlabel('Time')
plt.ylabel('Amplitude')
plt.title('Morlet Wavelet')
plt.legend()
plt.grid(True)
plt.show()

#%%
# # https://bea.stollnitz.com/blog/spectrograms-scaleograms/

# n = len(data)  # 128

#     # In the PyWavelets implementation, scale 1 corresponds to a wavelet with
#     # domain [-8, 8], which means that it covers 17 samples (upper - lower + 1).
#     # Scale s corresponds to a wavelet with s*17 samples.
#     # The scales in scale_list range from 1 to 16.75. The widest wavelet is
#     # 17*16.75 = 284.75 wide, which is just over double the size of the signal.
# n=1000
# scale_list = np.arange(start=0, stop=n) / 8 + 1  # 128
# wavelet = "mexh"
# cwtmatr, freqs = pywt.cwt(data, scale_list, wavelet, sampling_period=0.01)
#     # return scaleogram
#%%
# plt.imshow(cwtmatr, extent=[-1, 1, 1, 31], aspect='auto',
#        vmax=abs(cwtmatr).max(), vmin=-abs(cwtmatr).max()) 

#%%

#%%

# scg.set_default_wavelet('cmor1-1.5')
# # scg.set_default_wavelet('gaus1')
# # scg.set_default_wavelet('cgau1')
# # scg.set_default_wavelet('shan0.5-2')
# # scg.set_default_wavelet('mexh')

# scales = np.arange(1, 1000)
# ax2 = scg.cws(time,data, scales, spectrum='amp', yscale='log', yaxis='frequency'); 

#%%

# scg.wavelist()

#%%

# scg.set_default_wavelet('cmor1-1.5')
# scales = np.arange(1, min(len(time)/10, 2000))
# ax2 = scg.cws(time,data, scales, spectrum='amp', clim=(0, 10)); 

#%%

# scg.plot_wavelets()

#%%
#jupytext --to notebook temp_wavelet_2.py
#jupyter nbconvert --to html --execute temp_wavelet_2.ipynb