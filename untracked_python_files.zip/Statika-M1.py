#!/usr/bin/env python
# coding: utf-8

# # Static tests
# 
# Zpracování dat z pulling tests 2021-03-22, M1.
# Rozdělení na zpravidla tři zatáhnutí, zpracování inlikonometrů (barvy, celkový náklon, major/minor), obrázky pro vizuální kontrolu, grafy moment versus náklon, lineární regrese, output v souboru `output_static_pull.csv`.
# Body pro linearni regresi jsou kresleny jako lomena cara, aby se odlisilo prvni, druhe a treti zatahnuti.
# 
# Done:
# 
# * Identification of three pulling tests, plot data for visual check
# * Separate each measurement to three parts
# * Process inclinometers in each parts like in dynamics
# * Plot the data for visual checking
# * Run in loop for all trees
# * Find the slopes of linear part in Force/incination graph
# * Output saved in csv file
# * Output is processed in the file `static_summary.ipynb`
# 
# Next steps:
# 
# * ...
# 
# TODO
# 
# * unify the code with the force/inclination in pull-release experiment? (the csv layout is different)
# * illustrate linear regression also by dots rather than by line
# 

# # Functions
# 
# Functions are partly from similar code for momentum/angle dynamic tests, just fixed for different table stucture.

# In[1]:


import pandas as pd
import glob
import os
from scipy.signal import find_peaks
from scipy.signal import savgol_filter
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress

# import streamlit as st


# In[2]:


def split_df_static_pulling(df_ori):
    """
    Analyzes data in static tests, with three pulls. Inputs the dataframe, 
    outputs the list of dictionaries with minimal force, maximal force 
    """
    df = df_ori.copy()
    # Divide domain into interval where force is large and small
    maximum = df["Force(100)"].max()
    df["Force_step"] = df["Force(100)"].max()
    df.loc[df["Force(100)"]<0.5*maximum, "Force_step"] = 0
    df.loc[df["Force(100)"].isna(), "Force_step"] = np.nan
    
    diffs = df["Force_step"].dropna().diff()
    steps = diffs[diffs!=0.0].dropna()
    
    # print(f"Steps index:{steps.index}")
    
    interval_start = np.array([0.0]+list(steps.index))
    interval_end = np.roll(interval_start,-1)
    
    i = 0
    time = []
    for start,end in zip (interval_start, interval_end):
        if start > end:
            continue
        i = i+1
        if i % 2 == 1:
            # odd interval, save the bounds and skip to the next interval
            prev_start = start
            prev_end = end
            continue
        df_subset = df.loc[start:end,"Force(100)"]
        maximum_idx = np.argmax(df_subset)
        t = {'maximum': df_subset.index[maximum_idx]}
        maximum_force = np.max(df_subset)
        upper_limit_force_idx = np.argmax(df_subset>0.8*maximum_force)
        upper_limit_force_time = df_subset.index[upper_limit_force_idx]
        t['upper_limit_force'] = upper_limit_force_time
    
        df_subset = df.loc[prev_start:prev_end,"Force(100)"]
        idxmin = df_subset.idxmin()
        t['minimum'] = idxmin
    
        df_subset = df_subset[idxmin:]
        df_subset = df_subset[::-1]
        
        lower_limit_force_idx = np.argmax(df_subset<0.2*maximum_force)
        lower_limit_force_time = df_subset.index[lower_limit_force_idx]
        t['lower_limit_force'] = lower_limit_force_time
        time = time + [t]
    return time

def process_inclinometers(df, height_of_anchorage=None, rope_angle=None, 
                          height_of_pt=None):
    """
    The input is dataframe loaded by pd.read_csv from pull_tests directory.
    
    * Converts Inclino(80) and Inclino(81) to blue and yellow respectively.
    * Evaluates the total angle of inclination
    * Evaluates horizontal and vertical forces
    * 
    """
    # convert multiindex to single index
    sloupce = df.columns
    # sloupce = [f"{i[0]}/{i[1]}" for i in sloupce]
    sloupce = [i.replace("Inclino(80)","blue").replace("Inclino(81)","yellow") for i in sloupce]    
    df.columns = sloupce    
        #process columns
    df.loc[:,["blue"]] = arctand(np.sqrt((tand(df["blueX"]))**2 + (tand(df["blueY"]))**2 ))
    df.loc[:,["yellow"]] = arctand(np.sqrt((tand(df["yellowX"]))**2 + (tand(df["yellowY"]))**2 ))    
    for inclino in ["blue","yellow"]:
         # najde maximum bez ohledu na znamenko
         maxima = df[[f"{inclino}X",f"{inclino}Y"]].abs().max()
         # vytvori sloupce blue_Maj, blue_Min, yellow_Maj,  yellow_Min....hlavni a vedlejsi osa
         if maxima[f"{inclino}X"]>maxima[f"{inclino}Y"]:
             df.loc[:,[f"{inclino}_Maj"]] = df[f"{inclino}X"]
             df.loc[:,[f"{inclino}_Min"]] = df[f"{inclino}Y"]
         else:
             df.loc[:,[f"{inclino}_Maj"]] = df[f"{inclino}Y"]
             df.loc[:,[f"{inclino}_Min"]] = df[f"{inclino}X"]
         # Najde pozici, kde je extremalni hodnota - nejkladnejsi nebo nejzapornejsi
         idx = df[f"{inclino}_Maj"].abs().idxmax()
         # promenna bude jednicka pokus je extremalni hodnota kladna a minus
         # jednicka, pokud je extremalni hodnota zaporna
         if pd.isna(idx):
             znamenko = 1
         else:
             znamenko = np.sign(df[f"{inclino}_Maj"][idx])
         # V zavisosti na znamenku se neudela nic nebo zmeni znamenko ve sloupcich
         # blueM, blueV, yellowM, yellowV
         for axis in ["_Maj", "_Min"]:
             df.loc[:,[f"{inclino}{axis}"]] = znamenko * df[f"{inclino}{axis}"]    
         # convert index to multiindex
    # evaluate the horizontal and vertical component
    if rope_angle is None:
        # If rope angle is not given, use the data from the table
        rope_angle = df['RopeAngle(100)']
    # evaluate horizontal and vertical force components and moment
    df.loc[:,['F_horizontal']] = df['Force(100)'] * np.cos(np.deg2rad(rope_angle))
    df.loc[:,['F_vertical']] = df['Force(100)'] * np.sin(np.deg2rad(rope_angle))
    df.loc[:,['M']] = df['F_horizontal'] * height_of_anchorage
    df.loc[:,['M_Pt']] = df['F_horizontal'] * ( height_of_anchorage - height_of_pt )
    sloupce = [i.split("/") for i in df.columns]
    sloupce = [i if len(i)>1 else [i[0],'nan'] for i in sloupce ]
    # df.columns = pd.MultiIndex.from_tuples(sloupce)
    return df
    
def tand(angle):
    """
    Evaluates tangens of the angle. The angli is in degrees.
    """
    return np.tan(np.deg2rad(angle))
def arctand(value):
    """
    Evaluates arctan. Return the angle in degrees.
    """
    return np.rad2deg(np.arctan(value))    


# In[3]:


# Visual check

measurement = "1"
date = "2021-03-22"
year,month,day=date.split("-")
tree = "16"

df = pd.read_csv(f"./ERC/ERC/01_Mereni_Babice_{day}{month}{year}_optika_zpracovani/pulling_tests/BK_{tree}_M{measurement}.TXT",
                  skiprows=55, 
                  decimal=",",
                  sep='\t+',    
                  skipinitialspace=True,
                  na_values="-", 
                  engine='python'
)

df["Time"] = df["Time"] - df["Time"][0]
df.index = df["Time"]

time = split_df_static_pulling(df)
fig, ax = plt.subplots()
df[["Force(100)"]].plot(ax=ax)
ax.grid()
for _ in time:
    s = _["minimum"]
    e = _["maximum"]
    df.loc[s:e,"Force(100)"].plot(color="C0", lw=4, ax=ax)
    s = _["lower_limit_force"]
    e = _["upper_limit_force"]
    df.loc[s:e,"Force(100)"].plot(lw=4, ax=ax)


# In[4]:


df_pt_notes = pd.read_csv("./PT_notes/PT_notes_with_pt.csv", sep=",")
df_pt_notes.index = df_pt_notes["tree"]

# Rope angle
rope_angle = df_pt_notes.at[int(tree),'angle_of_anchorage']
height_of_anchorage = df_pt_notes.at[int(tree),'height_of_anchorage']
height_of_pt = df_pt_notes.at[int(tree),'height_of_pt']

fig,ax = plt.subplots()

legend = []
marker = ["0","s","d","^"]
for i,_ in enumerate(time):
    s = _["lower_limit_force"]
    e = _["upper_limit_force"]
    df_subset = df.loc[s:e,:]
    df_subset = process_inclinometers(df_subset, height_of_anchorage=height_of_anchorage, 
                                      rope_angle=rope_angle, height_of_pt=height_of_pt)
    for color in ["blue","yellow"]:
        
        x,y = df_subset.loc[:,[color, "M"]].values.T
        ax.plot(x, y, lw=i+1,
                label=f"{color}-{i}", 
                color="C0" if color=="blue" else "C1"
               )
        # df_subset.loc[:,[color,"M"]].plot(x=color, ax=ax)
        
ax.legend(title = "Inclinometer color\nand the number of pull")        
ax.set(ylabel="Momentum", xlabel="angle", title=f"{date} Tree {tree}")


# In[5]:


time


# # Spuštění na všechny soubory
# 
# Note: the date and path is hardcoded according to the jupyter.mendelu.cz

# In[13]:


def process_tree(tree, year = "2021", month ="03", day="22"):
    """
    Function to process one tree. 
    
    * Reads the csv data from TXT files
    * Splits three pull time intervals
    * Plots force-time diagram for verifications
    * Plots momentum/angle diagrams
    * Finds and return the slope and rvalues from least squares 
      (https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.linregress.html)
    """
    df = pd.read_csv(f"./ERC/ERC/01_Mereni_Babice_{day}{month}{year}_optika_zpracovani/pulling_tests/BK_{tree}_M{measurement}.TXT",
                      skiprows=55, 
                      decimal=",",
                      sep='\t+',    
                      skipinitialspace=True,
                      na_values="-", 
                      engine='python'
    )
    date = f"{year}-{month}-{day}"
    
    df["Time"] = df["Time"] - df["Time"][0]
    df.index = df["Time"]
    
    time = split_df_static_pulling(df)
    fig, ax = plt.subplots()
    df[["Force(100)"]].plot(ax=ax)
    ax.grid()
    for _ in time:
        s = _["minimum"]
        e = _["maximum"]
        df.loc[s:e,"Force(100)"].plot(color="C0", lw=4, ax=ax)
        s = _["lower_limit_force"]
        e = _["upper_limit_force"]
        df.loc[s:e,"Force(100)"].plot(lw=4, ax=ax)
    ax.set(title=f"Tree {tree}")
    fig.savefig(f"figs_static/BK{tree}-{year}-{month}-{day}-force.png")
    
    df_pt_notes = pd.read_csv("./PT_notes/PT_notes_with_pt.csv", sep=",")
    df_pt_notes.index = df_pt_notes["tree"]
    
    # Rope angle
    rope_angle = df_pt_notes.at[int(tree),'angle_of_anchorage']
    height_of_anchorage = df_pt_notes.at[int(tree),'height_of_anchorage']
    height_of_pt = df_pt_notes.at[int(tree),'height_of_pt']
    
    fig,ax = plt.subplots()
    
    all_coeffs = []
    marker = ["0","s","d","^"]
    for i,_ in enumerate(time):
        s = _["lower_limit_force"]
        e = _["upper_limit_force"]
        df_subset = df.loc[s:e,:]
        df_subset = process_inclinometers(df_subset, height_of_anchorage=height_of_anchorage, 
                                          rope_angle=rope_angle, height_of_pt=height_of_pt)
        for color in ["blue","yellow"]:
            
            x,y = df_subset.loc[:,[color, "M"]].dropna().values.T
            
            ax.plot(x, y, lw=i+1,
                    label=f"{color}-{i}", 
                    color="C0" if color=="blue" else "C1"
                   )
            # print(f"X: {len(x)}")
            try:
                coeffs = linregress(x,y)
                all_coeffs = all_coeffs + [
                    {'date': date, 'tree': tree, 'inclinometer':color, 'pull':i , 
                     'coefficients': coeffs, 
                     'slope': coeffs.slope, 'rvalue':coeffs.rvalue}]
                # print(f"Tree {tree}, pulling {i}, color {color}, {coefs}")
                t_ = np.linspace(x.min(),x.max(),3)
                ax.plot(t_, coeffs.slope*t_+coeffs.intercept, color='gray')
            except:
                all_coeffs = all_coeffs + [
                    {'date': date, 'tree': tree, 'inclinometer':color, 'pull':i , 
                     'coefficients': np.nan, 'slope': np.nan, 'rvalue': np.nan}
                    ]
                print (f"Linear regression failed for tree {tree}, pull {i}, inclinometer {color}")

            
    ax.legend(title = "Inclinometer color\nand the number of pull")        
    ax.set(ylabel="Momentum", xlabel="angle", title=f"{date} Tree {tree}")
    fig.savefig(f"figs_static/BK{tree}-{year}-{month}-{day}-momentum_angle.png")
    return all_coeffs

import glob
files = glob.glob("./ERC/ERC/01_Mereni_Babice_22032021_optika_zpracovani/pulling_tests/B*M1.TXT")    # find files with data
data = [{'tree': i[-9:-7]} for i in files]  # extract tree a measurement numbers
data.sort(key = lambda x: x['tree'])  # sort data
print(data)
all_coeffs = []
for tree_ in data:
    tree = tree_['tree']
    try: 
        all_coeffs += process_tree(tree)
        print (f"Tree {tree} finished.")
    except:
        print (f"Tree {tree} failed, run procestree({tree}) in debug mode.")


# In[14]:


df = pd.DataFrame(all_coeffs)
df


# In[15]:


df.to_csv("output_static_pull.csv")


# In[ ]:




